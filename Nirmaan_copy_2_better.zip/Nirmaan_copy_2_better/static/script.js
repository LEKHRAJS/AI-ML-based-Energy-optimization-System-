// script.js

function getWeather() {
    var city = document.getElementById('city').value;
    var temperatureElement = document.getElementById('temperature');

    $.ajax({
        url: '/weather',
        data: { city: city },
        beforeSend: function () {
            alert('Please wait while we fetch the current temperature.');
        },
        success: function (response) {
            if (response.temperature) {
                temperatureElement.textContent = 'Current temperature: ' + response.temperature + '°C';
                temperatureElement.setAttribute('data-temperature', response.temperature);
            } else {
                temperatureElement.textContent = 'Current temperature: N/A';
            }
        },
        error: function () {
            alert('Failed to fetch weather data. Please try again later.');
        }
    });
}

function predictEnergy() {
    var city = document.getElementById('city').value;
    var temperature = document.getElementById('temperature').getAttribute('data-temperature');
    var future_temperature = document.getElementById('future_temperature').value;

    if (!temperature || temperature === 'N/A') {
        alert('Please wait while we fetch the current temperature.');
        return;
    }

    $.ajax({
        url: '/predict',
        method: 'POST',
        data: { city: city, temperature: temperature, future_temperature: future_temperature },
        success: function (response) {
            var predictionElement = document.getElementById('prediction');
            var futureDemandElement = document.getElementById('future_demand');
            var recommendationElement = document.getElementById('recommendation');

            predictionElement.textContent = 'Predicted energy consumption: ' + response.prediction.toFixed(2);
            futureDemandElement.textContent = 'Future energy demand: ' + response.future_demand.toFixed(2);
            recommendationElement.textContent = 'Recommendation: ' + response.recommendation;
        },
        error: function () {
            alert('Failed to fetch energy consumption data. Please try again later.');
        }
    });
}
