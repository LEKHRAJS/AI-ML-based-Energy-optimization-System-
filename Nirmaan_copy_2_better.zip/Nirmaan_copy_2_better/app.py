# app.py

from flask import Flask, jsonify, request, render_template
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LinearRegression
import numpy as np
import pyowm
import pandas as pd

app = Flask(__name__)

# Initialize OpenWeatherMap API
owm = pyowm.OWM('12d3db6908ee5c9354c4035b6b580628')

# Load the dataset
dataset_path = "electricity.csv"
df = pd.read_csv(dataset_path)

# Extract numerical part from the 'Year' column and convert it to numeric
df['Year'] = df['Year'].str.extract('(\d+)').astype(float)

# Fill missing values with the median value
df['Year'].fillna(df['Year'].median(), inplace=True)

# Set seed for reproducibility
np.random.seed(0)

# Simulate energy usage data for 24 hours
energy_data = np.random.randint(10, 100, size=24)

# Initialize MinMaxScaler
scaler = MinMaxScaler()

# Initialize Linear Regression model
model = LinearRegression()

# Initialize average consumption by city
average_consumption_by_city = df.groupby('City ').mean()['Consumption of Electricity (in lakh units)-Total Consumption']

# Function to update temperature based on selected city
def get_current_temperature(city_name):
    try:
        observation = owm.weather_manager().weather_at_place(city_name)
        weather_data = observation.weather
        real_time_temperature = weather_data.temperature('celsius')['temp']
        return real_time_temperature
    except Exception as e:
        print("Error:", e)
        return None

# Endpoint to render HTML page
@app.route('/')
def home():
    return render_template('index.html', cities=average_consumption_by_city.index)

# Endpoint to get current temperature
@app.route('/weather')
def weather():
    city = request.args.get('city')
    temperature = get_current_temperature(city)
    return jsonify({'temperature': temperature})

# Endpoint to predict energy consumption and future demand
@app.route('/predict', methods=['POST'])
def predict():
    city = request.form['city']
    temperature = float(request.form['temperature'])
    future_temperature = float(request.form['future_temperature'])

    if temperature is not None and future_temperature is not None:
        # Scale the real-time weather data
        scaled_weather = scaler.transform([[temperature]])  # Remove the dummy feature
        scaled_future_weather = scaler.transform([[future_temperature]])  # Remove the dummy feature

        # Predict energy consumption
        predicted_energy = model.predict(scaled_weather)  

        # Predict future energy demand
        future_energy_demand = model.predict(scaled_future_weather)  

        # Recommend energy consumption optimization
        recommendation = recommend_optimization(predicted_energy)

        return jsonify({'prediction': predicted_energy[0], 'future_demand': future_energy_demand[0], 'recommendation': recommendation})
    else:
        return jsonify({'error': 'Failed to fetch weather data for the selected city'})

def recommend_optimization(energy_consumption):
    if energy_consumption < 0.4:
        return "Your energy consumption is low. No optimization needed."
    elif energy_consumption >= 0.4 and energy_consumption < 0.7:
        return "Your energy consumption is moderate. You can optimize by turning off unnecessary lights and appliances."
    else:
        return "Your energy consumption is high. Consider using energy-efficient appliances and reducing usage during peak hours."

if __name__ == '__main__':
    # Split data into features and target
    X = df['Year'].values.reshape(-1, 1)  # Only use year data as the feature
    y = df['Consumption of Electricity (in lakh units)-Total Consumption'].values  # Energy usage data as the target

    # Scale the data
    scaler.fit(X)
    X_scaled = scaler.transform(X)

    # Train the model
    model.fit(X_scaled, y)
    
    app.run(debug=True, port=8080)
