import pandas as pd
import os

# Directory containing temperature data CSV files
directory = 'temperature_data_directory'

# List to store DataFrames
dfs = []

# Loop through each file in the directory
for filename in os.listdir(directory):
    if filename.endswith(".csv"):
        # Read CSV file into DataFrame
        filepath = os.path.join(directory, filename)
        df = pd.read_csv(filepath)
        # Add a column for city name
        city = filename.split('.')[0]
        df['City'] = city
        # Append DataFrame to the list
        dfs.append(df)

# Concatenate DataFrames into one
merged_df = pd.concat(dfs, ignore_index=True)

# Save merged DataFrame to a new CSV file
merged_df.to_csv('merged_temperature_data.csv', index=False)
